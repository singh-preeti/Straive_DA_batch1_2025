# Banking Flask App with Swagger and ML (SQLite version)

## Features
- CRUD operations on customers (SQLite + SQLAlchemy)
- Swagger UI for API documentation
- Logistic Regression model training & prediction

## Setup
1. Install requirements: `pip install -r requirements.txt`
2. Start the app: `python app.py`
3. Open Swagger docs at: `http://127.0.0.1:5000/apidocs`
