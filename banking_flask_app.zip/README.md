# Banking Flask App with Swagger, MySQL, and ML

## Features
- CRUD operations on customers (MySQL + SQLAlchemy)
- Swagger UI for API documentation
- Logistic Regression model training & prediction

## Setup
1. Install requirements: `pip install -r requirements.txt`
2. Run the SQL init script (`db_init.sql`) to create database and table.
3. Start the app: `python app.py`
4. Open Swagger docs at: `http://127.0.0.1:5000/apidocs`
