import pytest
from banking import Account, InsufficientBalanceError

@pytest.fixture
def accounts():
    acc1 = Account(owner="Alice", balance=10000, annual_rate=0.05)
    acc2 = Account(owner="Bob", balance=5000, annual_rate=0.05)
    return acc1, acc2


def test_overdraft_transfer(accounts):
    acc1, acc2 = accounts
    with pytest.raises(InsufficientBalanceError):
        acc1.transfer(acc2, 20000)
    assert acc1.balance == 10000
    assert acc2.balance == 5000


def test_chained_transactions(accounts):
    acc1, acc2 = accounts
    acc1.deposit(2000)
    acc1.withdraw(500)
    acc1.transfer(acc2, 1000)
    assert acc1.balance == 10500
    assert acc2.balance == 6000
    assert acc1.history[-1]["type"] == "transfer"


@pytest.mark.parametrize("rate,years,expected", [
    (0.03, 1, 10300.00),
    (0.05, 5, 12762.82),
    (0.07, 10, 19671.51),
])
def test_compound_interest_param(rate, years, expected):
    acc = Account("Test", balance=10000, annual_rate=rate)
    result = acc.calculate_compound_interest(years)
    assert result == pytest.approx(expected, rel=1e-2)


def test_large_years_interest_precision():
    acc = Account("Test", balance=10000, annual_rate=0.07)
    result = acc.calculate_compound_interest(25)
    expected = 10000 * ((1 + 0.07) ** 25)
    assert result == pytest.approx(expected, rel=1e-6)


def test_multiple_deposits(accounts):
    acc1, _ = accounts
    for _ in range(10):
        acc1.deposit(100)
    assert acc1.balance == 11000


def test_interest_then_withdraw():
    acc = Account("Alice", balance=5000, annual_rate=0.10)
    acc.balance = acc.calculate_compound_interest(1)
    acc.withdraw(2000)
    assert acc.balance == pytest.approx(3500, rel=1e-2)


def test_calculate_emi_short_vs_long_term():
    short_emi = Account.calculate_emi(principal=100000, annual_rate=0.08, years=1)
    long_emi = Account.calculate_emi(principal=100000, annual_rate=0.08, years=30)
    assert short_emi > long_emi
    assert long_emi * 360 > 100000


def test_transaction_history(accounts):
    acc1, _ = accounts
    acc1.deposit(1000)
    acc1.withdraw(500)
    assert acc1.history[0]["type"] == "deposit"
    assert acc1.history[1]["type"] == "withdraw"
    assert acc1.history[-1]["balance"] == acc1.balance


def test_zero_and_negative_interest():
    acc = Account("Zero", balance=10000, annual_rate=0.0)
    assert acc.calculate_compound_interest(5) == 10000

    acc = Account("Negative", balance=10000, annual_rate=-0.01)
    result = acc.calculate_compound_interest(5)
    assert result < 10000


def test_full_year_banking():
    acc = Account("Alice", balance=20000, annual_rate=0.06)
    for _ in range(12):
        acc.deposit(500)
    acc.balance = acc.calculate_compound_interest(1)
    acc.withdraw(3000)
    expected = (20000 + 6000) * 1.06 - 3000
    assert acc.balance == pytest.approx(expected, rel=1e-2)
